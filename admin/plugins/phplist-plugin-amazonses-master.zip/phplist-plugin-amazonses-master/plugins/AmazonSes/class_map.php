<?php

return array(
    'phpList\plugin\AmazonSes\MailClient' => $base . '/AmazonSes/MailClient.php',
);
